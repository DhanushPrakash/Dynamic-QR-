import unittest
import time
from dynamic_qr import generate_unique_id

class TestGenerateUniqueID(unittest.TestCase):

    def test_unique_id_generation(self):
        product_name = "Rolex Watch"
        index = 1

        unique_id_1 = generate_unique_id(product_name, index)
        time.sleep(1)  # Ensure time difference for uniqueness
        unique_id_2 = generate_unique_id(product_name, index)

        self.assertNotEqual(unique_id_1, unique_id_2, "Unique IDs should be different for different times.")
        self.assertEqual(len(unique_id_1), 64, "Unique ID should be a 64-character hexadecimal string.")
        self.assertEqual(len(unique_id_2), 64, "Unique ID should be a 64-character hexadecimal string.")

if __name__ == '__main__':
    unittest.main()
