import unittest
import os
from dynamic_qr import embed_qr_in_gif, generate_qr_code
from PIL import Image

class TestEmbedQRInGIF(unittest.TestCase):

    def test_embed_qr_in_gif(self):
        # Generate a sample QR code
        product_info = "Product Name: Louis Vuitton Wallet\nBrand: Louis Vuitton\nCondition: Second-hand"
        qr_img = generate_qr_code(product_info)

        # Paths for input GIF and output GIF
        gif_path = "C:/Users/shrey/Downloads/Dynamic_QR/spherewave 3.gif"
        output_path = "C:/Users/shrey/Downloads/test_output.gif"

        # Embed the QR code in the GIF
        result = embed_qr_in_gif(qr_img, gif_path, output_path)

        # Check if the output GIF was created and is not empty
        self.assertEqual(result, output_path, "The function should return the output file path.")
        self.assertTrue(os.path.exists(output_path), "Output GIF file should be created.")
        self.assertGreater(os.path.getsize(output_path), 0, "Output GIF file should not be empty.")

        # Clean up the generated file
        os.remove(output_path)

if __name__ == '__main__':
    unittest.main()
