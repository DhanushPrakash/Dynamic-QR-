import unittest
import os  # Import the os module
from dynamic_qr import generate_qr_code
from PIL import Image

class TestBlackBox(unittest.TestCase):

    def test_qr_code_generation_and_decoding(self):
        # Simulate user input for product information
        product_info = "Product Name: Chanel Perfume\nBrand: Chanel\nCondition: Second-hand"

        # Generate QR code based on user input
        qr_img = generate_qr_code(product_info)
        
        # Save the QR image temporarily to simulate user handling
        qr_img_path = "temp_qr_code.png"
        qr_img.save(qr_img_path)

    
        # Clean up temporary file
        os.remove(qr_img_path)

if __name__ == '__main__':
    unittest.main()