import unittest
from dynamic_qr import generate_qr_code
from qrcode.image.pil import PilImage  # Import the correct class for checking

class TestQRCodeGeneration(unittest.TestCase):

    def test_qr_code_with_custom_colors(self):
        product_info = "Product Name: Gucci Bag\nBrand: Gucci\nCondition: Second-hand"
        fill_color = "black"
        back_color = "yellow"

        qr_img = generate_qr_code(product_info, fill_color=fill_color, back_color=back_color)

        # Check if the returned object is an instance of qrcode.image.pil.PilImage
        self.assertIsInstance(qr_img, PilImage, "Generated QR code should be an instance of qrcode.image.pil.PilImage.")
        
        # Convert to PIL.Image.Image for pixel checks
        qr_img_pil = qr_img._img  # Access the underlying PIL.Image.Image instance
        self.assertEqual(qr_img_pil.mode, "RGB", "QR code image should be in RGB mode.")

        # Check the color of one of the pixels in the QR code (top-left corner)
        self.assertEqual(qr_img_pil.getpixel((10, 10)), (255, 255, 0), "Background color should match the specified back_color.")

if __name__ == '__main__':
    unittest.main()
