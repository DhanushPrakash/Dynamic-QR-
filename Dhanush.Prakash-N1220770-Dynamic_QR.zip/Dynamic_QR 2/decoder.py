import os
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageSequence
import tkinter as tk
from tkinter import filedialog, messagebox

# Function to enhance and decode a QR code from an image or GIF using OpenCV
def decode_qr_from_file(file_path):
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return None
    
    img = Image.open(file_path)
    qr_codes = set()  # Use a set to store unique QR codes

    for i, frame in enumerate(ImageSequence.Iterator(img)):
        frame = frame.convert('RGB')
        img_cv = cv2.cvtColor(np.array(frame), cv2.COLOR_RGB2BGR)
        
        # Function to attempt decoding
        def try_decoding(image, attempt_description):
            detector = cv2.QRCodeDetector()
            data, vertices_array, binary_qrcode = detector.detectAndDecode(image)
            if data and data not in qr_codes:  # Only add unique data
                print(f"Decoded data from {attempt_description}: {data}")
                qr_codes.add(data)
            return data, vertices_array

        # Attempt 1: Direct decode
        try_decoding(img_cv, f"frame {i}, direct decode")

        # Attempt 2: Resize the image (scale up)
        img_cv_resized = cv2.resize(img_cv, None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)
        try_decoding(img_cv_resized, f"frame {i}, resized image")

        # Attempt 3: Convert to grayscale and thresholding
        img_gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
        _, img_thresh = cv2.threshold(img_gray, 128, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        try_decoding(img_thresh, f"frame {i}, thresholded grayscale")

        # Attempt 4: Increase contrast
        enhancer = ImageEnhance.Contrast(frame)
        img_contrast = enhancer.enhance(2)  # Increase contrast
        img_cv_contrast = cv2.cvtColor(np.array(img_contrast), cv2.COLOR_RGB2BGR)
        try_decoding(img_cv_contrast, f"frame {i}, contrast enhanced")
    
    if qr_codes:
        print("QR Codes found:", list(qr_codes))
        return list(qr_codes)
    else:
        print("No QR Code detected in any frame.")
        return None  # Return None if QR code is not detected in any frame

# Function to display the decoded product information
def display_decoded_info(decoded_info):
    if decoded_info:
        root = tk.Tk()
        root.title("Decoded Product Information")
        label = tk.Label(root, text="\n".join(decoded_info), bg='light green', font=("Helvetica", 12))
        label.pack(padx=10, pady=10)
        root.mainloop()
    else:
        print("No decoded information to display.")

# Function to upload and decode the QR code
def upload_and_decode():
    file_path = filedialog.askopenfilename(
        title="Select an image or GIF",
        filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")]
    )
    if file_path:
        decoded_message = decode_qr_from_file(file_path)
        if decoded_message:
            display_decoded_info(decoded_message)
        else:
            messagebox.showerror("Error", "No QR Code detected or unable to decode.")

# Main function to create the GUI
def main():
    root = tk.Tk()
    root.title("QR Code Decoder")

    # Add a button for uploading and decoding a QR code
    decode_button = tk.Button(root, text="Decode QR", command=upload_and_decode)
    decode_button.pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    main()
