def test_decode_multiple_qr_with_one_incorrect(self):
    file_path = "C:/Users/shrey/Downloads/Dynamic_QR/multiple_qr_one_corrupt.png"  # Path to an image with multiple QR codes

    decoded_qr = decode_qr_from_file(file_path)

    self.assertIsNotNone(decoded_qr, "The function should return decoded QR data.")
    self.assertIsInstance(decoded_qr, list, "The decoded QR data should be returned as a list.")
    self.assertGreater(len(decoded_qr), 1, "The decoded QR list should contain multiple items.")
    self.assertNotIn(None, decoded_qr, "The list should not contain None if at least one QR code was decodable.")
