import unittest
from dynamic_qr import generate_unique_id

class TestProductVerification(unittest.TestCase):

    def test_generate_unique_id(self):
        unique_id = generate_unique_id("Rolex Watch", 0)
        self.assertEqual(len(unique_id), 64, "Unique ID should be 64 characters long")
        print("test_generate_unique_id passed")

if __name__ == "_main_":
    unittest.main()