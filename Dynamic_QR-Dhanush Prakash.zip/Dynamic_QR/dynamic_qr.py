import hashlib
import time
import qrcode
import tkinter as tk
from PIL import Image, ImageTk, ImageSequence
import os
import pyautogui  # Import the pyautogui library

# Function to generate a unique ID for each product
def generate_unique_id(product_name, index):
    data_string = f"{product_name}-{index}-{int(time.time())}"
    unique_id = hashlib.sha256(data_string.encode()).hexdigest()
    return unique_id

# Function to generate a QR code with reduced brightness
def generate_qr_code(product_info, fill_color="gray", back_color="white"):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # High error correction
        box_size=6,  # Keep the box size the same
        border=4,
    )
    qr.add_data(product_info)
    qr.make(fit=True)
    img = qr.make_image(fill_color=fill_color, back_color=back_color)
    return img

# Function to embed the QR code into every frame of the GIF
def embed_qr_in_gif(qr_img, gif_path, output_path):
    try:
        gif = Image.open(gif_path)
        frames = []

        # Convert the QR code image to have transparency
        qr_img = qr_img.convert("RGBA")
        datas = qr_img.getdata()

        new_data = []
        for item in datas:
            # Make the white parts fully transparent
            if item[0] > 200 and item[1] > 200 and item[2] > 200:
                new_data.append((255, 255, 255, 0))
            else:
                # Set opacity for scannability while reducing brightness
                new_data.append((item[0], item[1], item[2], 200))

        qr_img.putdata(new_data)

        for frame in ImageSequence.Iterator(gif):
            frame = frame.convert("RGBA")

            qr_resized = qr_img.resize((frame.width // 3, frame.height // 3))  # Keep the QR code size consistent

            # Position the QR code closer to the center for better visibility
            position = ((frame.width - qr_resized.width) // 2, (frame.height - qr_resized.height) // 2)
            frame.paste(qr_resized, position, qr_resized)

            frames.append(frame)

        frames[0].save(
            output_path,
            save_all=True,
            append_images=frames[1:],
            loop=0,
            duration=gif.info['duration'],
            disposal=2
        )
        print(f"GIF with embedded QR code saved to {output_path}")
        return output_path
    except Exception as e:
        print(f"Error processing GIF: {e}")
        return None

# Function to display the GIF
def display_gif(file_path, label):
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return

    try:
        img = Image.open(file_path)
        frames = [ImageTk.PhotoImage(frame.copy()) for frame in ImageSequence.Iterator(img)]

        def update(ind):
            frame = frames[ind]
            ind = (ind + 1) % len(frames)
            label.configure(image=frame)
            label.image = frame
            label.after(100, update, ind)

        label.after(0, update, 0)
    except Exception as e:
        print(f"Error displaying GIF: {e}")

# Function to alternate between QR codes and GIFs for all products
def alternate_display(root, qr_paths, labels, products):
    current_product = 0  # To track which product is being displayed
    total_products = len(qr_paths)

    def switch_display():
        nonlocal current_product
        if current_product < total_products:
            display_gif(qr_paths[current_product], labels[current_product]['gif'])
        current_product = (current_product + 1) % total_products
        root.after(5000, switch_display)  # Switch every 5 seconds for better viewing

    switch_display()

# Function to take a screenshot of the current QR code displayed in a GIF
def take_screenshot(root, label, screenshot_path):
    root.update()  # Update the GUI to ensure it's fully rendered
    x = label.winfo_rootx()
    y = label.winfo_rooty()
    width = label.winfo_width()
    height = label.winfo_height()
    screenshot = pyautogui.screenshot(region=(x, y, width, height))
    screenshot.save(screenshot_path)
    print(f"Screenshot saved to {screenshot_path}")

# Callback function for screenshot button
def screenshot_button_callback(root, label, screenshot_path):
    def callback():
        take_screenshot(root, label, screenshot_path)
    return callback

# Main function to handle product verification and QR/GIF display
def main():
    products = [
        {"name": "Rolex Watch", "brand": "Rolex", "description": "Luxury watch with gold finish, lightly used, fully functional."},
        {"name": "Gucci Bag", "brand": "Gucci", "description": "High-end leather bag, second-hand, with minor wear."},
        {"name": "Louis Vuitton Wallet", "brand": "Louis Vuitton", "description": "Second-hand leather wallet, excellent condition."},
        {"name": "Chanel Perfume", "brand": "Chanel", "description": "Classic fragrance, partially used, original packaging."},
    ]

    gif_path = "C:/Users/shrey/Downloads/Dynamic_QR/spherewave 3.gif"  # Updated path
    qr_paths = []
    labels = []

    root = tk.Tk()
    root.title("Product Animation")
    root.config(bg='white')

    for i, product in enumerate(products):
        unique_id = generate_unique_id(product["name"], i)
        product_info = (f"Product Name: {product['name']}\n"
                        f"Brand: {product['brand']}\n"
                        f"Condition: {'Second-hand'}\n"
                        f"Description: {product['description']}\n"
                        f"Unique ID: {unique_id}")

        # Make the QR code less bright by using a gray color
        qr_img = generate_qr_code(product_info, fill_color="gray", back_color="white")
        output_gif_path = f"C:/Users/shrey/Downloads/product_{i+1}_output.gif"
        gif_with_qr = embed_qr_in_gif(qr_img, gif_path, output_gif_path)
        if gif_with_qr:
            # Create frames for GIF and button
            frame = tk.Frame(root, bg='white')
            frame.pack()

            label = tk.Label(frame, bg='black')
            label.pack()

            button = tk.Button(frame, text="Take Screenshot", command=screenshot_button_callback(root, label, f"C:/Users/shrey/Downloads/product_{i+1}_screenshot.png"))
            button.pack()

            qr_paths.append(gif_with_qr)
            labels.append({'gif': label, 'button': button})

            # Display the GIF to take a screenshot
            display_gif(gif_with_qr, label)

    if qr_paths:
        alternate_display(root, qr_paths, labels, products)
    else:
        print("No GIFs to display.")

    root.mainloop()

if __name__ == "__main__":
    main()
